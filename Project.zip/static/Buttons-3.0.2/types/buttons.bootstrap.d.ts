
import DataTable from 'datatables.net-buttons';

export default DataTable;
export * from 'datatables.net-buttons';
